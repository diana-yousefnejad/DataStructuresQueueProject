#include <iostream>
using namespace std;
class Node {

  // Write Node Description here
  // Node variables are given in Assignment
private:
  int data;
  Node *nextNode;

public:
  Node(int data) {
    this->data = data;
    nextNode = nullptr;
  }
  int getData() const { 
    return data; 
  }
  void setData(int data) { 
    this->data = data; 
  }
  Node *getNextNode() { 
    return nextNode; 
  }
  void setNextNode(Node *nextNode) { 
    this->nextNode = nextNode; 
  }
};
class LLStack {
  // Stack ADT
  //  Use Appropriate Variables
  //  Write Stack methods here
  //  Stack is implemented as a linked list
  //   Stack methods are Push(), Pop(), Peek()
private:
  Node *top;
  int stackSize;

public:
  LLStack() {
    stackSize = 0;
    top = NULL;
  }

  ~LLStack() {
    Node *temp = top;
    while (top) {
      top = top->getNextNode();
      delete temp;
      temp = top;
    }
  }
  Node *getTop() { 
    return top; 
  }

  void setTop(Node *top) { 
    this->top = top; 
  }

  int getStackSize() const { 
    return stackSize; 
  }

  void setStackSize(int stackSize) { 
    this->stackSize = stackSize; 
  }

  void push(int data) {
    Node *newNode = new Node(data);
    if (stackSize == 0) {
      top = newNode;
    } else {

      newNode->setNextNode(top);
      top = newNode;
    }
    stackSize++;
  }
  Node *pop() {
    if (stackSize == 0) {
      cout << "invalid";
    }
    Node *temp = top;
    if (stackSize == 1) {
      top = nullptr;
    } else {
      top = temp->getNextNode();
    }
    stackSize--;
    return temp;
    delete temp;
  }
  int peek() {
    int peaked;
    if (top == nullptr) {
      //cout << "Head: nullptr" << endl;
      return NULL;
    } else {
      peaked = top->getData();
      //cout << "Head: " << peaked << endl; 
    }
    return peaked;
  }

  void printStack(LLStack stack) {
    LLStack* tempStack = new LLStack();
    while (stack.getTop()!= NULL) {
      Node* temp = stack.getTop();
      cout << temp->getData() <<" ";
      tempStack->push(stack.pop()->getData());
    }
    while (tempStack->getTop() != NULL) {
      stack.push(tempStack->pop()->getData());
    }
      
  }
};

class StackQ {
  // Queue ADT
  //  This is your queue class
  //  Implement queue methods here
  //  Queue methods are given in the Assignment
  //  Queue is implemented by manipulating two stacks.
  //  You will need references to 2 stacks here
private:
  LLStack *enQStack;
  LLStack *deQStack;

public:
  StackQ() {
    enQStack = new LLStack();
    deQStack = new LLStack();
  }
  void enQ(int data) { 
    enQStack->push(data); 
  }
  Node *deQ() {
   if (deQStack->getStackSize()== 0 && enQStack->getStackSize()==0) {
   return NULL;
  }
    if (deQStack->getTop() == NULL) {
      while (enQStack->getTop() != NULL) {
        deQStack->push(enQStack->pop()->getData());
      }
    }
    return deQStack->pop();
  }
int peekQueue() {
  if (deQStack->getTop()== NULL && enQStack->getTop()==NULL) {
    return -1;
  }
  if (deQStack->getTop() == NULL) {
      while (enQStack->getTop() != NULL) {
        deQStack->push(enQStack->pop()->getData());
      }
    }
    return deQStack->peek();
}
  void printenQStack() { 
    enQStack->printStack(*enQStack); 
  }
  void printdeQStack() {
    deQStack->printStack(*deQStack); 
  }
void printQueue() {
  deQStack->printStack(*deQStack);
  LLStack * tempStack = new LLStack();
  while (enQStack->getTop() != NULL) {
    Node * temp1 = enQStack->pop();
    tempStack->push(temp1->getData());
  }
  while (tempStack->getTop() != NULL) {
   Node* temp = tempStack->getTop();
      cout << temp->getData()<<" ";
    Node * temp2 = tempStack->pop();
    enQStack->push(temp2->getData());
  }
    
}
  
  void printQueueSize() {
    cout << (enQStack->getStackSize() + deQStack->getStackSize());
  }
};
int main() {
StackQ* queue;
  int data;
  int x = 0;
  bool queueCreated = false;
  while (x != 8){

cout << "Pick an option on the menu\n";

cout << "MENU:\n";

cout << "1. Make a Queue\n";

cout << "2. Enqueue in the queue\n";

cout << "3. Dequeue from the queue\n";

cout << "4. Peek from the Queue\n";

cout << "5. Display the queue\n";

cout << "6. Display enQStack and deQStack\n";

cout << "7. Display size of the queue\n";

cout << "8. Exit\n";
    
  cin >> x;
    if (x<1 || x>8) {
      cout<<"not valid option, choose again from menu \n";
    continue;
    }
    switch(x) {
      case 1: 
      if (queueCreated == true) {
        cout << "error: already made queue\n";
      } else{
        cout <<"made queue\n";
        queue = new StackQ();
        queueCreated = true; 
      }
      break;
      case 2:
        if (queueCreated == false) {
          cout<<"error: need to make queue first before enqueueing\n";
        } else{
       cout << "Provide number you want to enqueue\n";
      cin>>data;
      queue->enQ(data);
      cout<<"print enQStack:\n";
      queue->printenQStack();
        cout<<"\n";
      cout<<"print queue:\n";
      queue->printQueue();
        cout<<"\n";
        }
      break;
      case 3:
        if (queueCreated == false) {
          cout<<"error: need to make queue first before dequeueing\n";
        } else{
      cout<<"Dequeue from the queue \n";
      Node* dequeued = queue->deQ();
        if (dequeued==NULL) {
        cout<<"error: can not dequeue from empty queue\n";
      }  else{
      cout << "dequeued element: " << dequeued->getData();
       cout<<"\n";
      cout<<"print enQStack:\n";
      queue->printenQStack();
       cout<<"\n";
      cout<<"print deQStack:\n";
      queue->printdeQStack();
       cout<<"\n";
      cout<<"print queue:\n";
      queue->printQueue();
      cout<<"\n";
        }
        }
      break;
      case 4:
        if (queueCreated == false) {
          cout<<"error: need to make queue first before peeking\n";
        } else{
      cout << "Peek from the Queue\n";
        
          if ( queue->peekQueue() == -1) {
            cout<<"error: can not peek from empty queue\n";
          }
          cout << "Peaked: " <<queue->peekQueue();
          cout<<"\n";
        }
      break;
      case 5:
        if (queueCreated == false) {
          cout<<"error: need to make queue first in order to display queue\n";
        } else{
      cout<<"Display the queue:\n";
      queue->printQueue();
        cout<<"\n";
        }
      break;
      case 6:
        if (queueCreated == false) {
          cout<<"error: need to make queue first before displaying enQStack and deQStack\n";
        } else{
      cout<<"Display enQStack and deQStack\n";
      cout<<"enQStack:\n";
      queue->printenQStack();
          cout<<"\n";
      cout<<"deQStack:\n";
      queue->printdeQStack();
          cout<<"\n";
        }
      break;
      case 7:
        if (queueCreated == false) {
          cout<<"error: need to make queue first before printing size of queue\n";
        } else{
        cout<<"Queue Size: \n";
          queue->printQueueSize();
          cout<<"\n";
        }
      break;
      case 8:
      cout<<"Exit";
    }
  }
  
}
